let story={},current="start";
const bg=document.getElementById("bg"),
char=document.getElementById("char"),
textBox=document.getElementById("text"),
choicesBox=document.getElementById("choices");

fetch("story.json").then(r=>r.json()).then(d=>{story=d;showScene(current)});

function showScene(k){
const s=story[k];current=k;
if(s.bg)bg.src="assets/"+s.bg;
if(s.char)char.src="assets/"+s.char;
textBox.textContent=s.text||"";
choicesBox.innerHTML="";
if(!s.choices)return;
s.choices.forEach(c=>{
const b=document.createElement("button");
b.textContent=c.text;
b.onclick=()=>showScene(c.next);
choicesBox.appendChild(b);
});
}